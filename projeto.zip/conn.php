<?php
    $dbhost = 'localhost';
    $dbusuario = 'root';
    $senha = '';
    $dbnome = 'spotted';
    $conn = new mysqli($dbhost,$dbusuario,$senha,$dbnome);

?>