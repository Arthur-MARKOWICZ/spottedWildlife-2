<style>
.logo {
  background-color: rgb(31, 158, 69);
  display: flex;
  justify-content: center;
  align-items: center;
  height: 120px;
  min-width: 100vw;
  width: 100%;
  padding-top: 30px;
  
}

img {
  width: 950px;
  height: 370px;
  max-height: 400%;
  max-width: 150%;
}

</style>

<header>
    <div class="logo">
        <img src="logo.png" alt="Logo do Site">
    </div>
</header>
